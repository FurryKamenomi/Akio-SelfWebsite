import * as ModuleCore from './module/index.js';

var i18n = new ModuleCore.Ci18n;
i18n.Process();

document.addEventListener('DOMContentLoaded', function () {
  ; (() => {
    var UserAgent = navigator.userAgent;
    var PlatformStyleNode = this.querySelector('link[detect-platform][rel="stylesheet/less"]') as HTMLLinkElement;
    PlatformStyleNode.setAttribute(
      'href', [
        '/asset/style/style',
        UserAgent.includes('mobile')
          ? 'mobile'
          : (UserAgent.includes('ipad')
            || UserAgent.includes('tablet')
            || UserAgent.includes('playbook')
          ) ? 'pad'
            : 'desktop',
        'less'
      ].join('.'));
  }).call(this);
});